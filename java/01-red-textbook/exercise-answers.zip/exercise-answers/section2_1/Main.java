package section2_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	
	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("１つ目の値を入力してください。:");
			String str1 = reader.readLine();
			System.out.print("2つ目の値を入力してください。:");
			String str2 = reader.readLine();
			int num1 = Integer.parseInt(str1);
			int num2 = Integer.parseInt(str2);
			System.out.println("積: " + (num1 * num2));
		} catch (IOException e) {
			System.out.println("Error");
		}
	}

}
