package section3_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main (String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("値を入力してください。:");
			String str = reader.readLine();
			int num = Integer.parseInt(str);
			if(num % 2 == 0) {
				System.out.println("入力された値は偶数です。");
			} else {
				System.out.println("入力された値は奇数です。");
			}
		} catch (IOException e) {
			System.out.println("Error");
		} catch (NumberFormatException e) {
			System.out.println("不正な入力です。");
		}
	}
	
}
