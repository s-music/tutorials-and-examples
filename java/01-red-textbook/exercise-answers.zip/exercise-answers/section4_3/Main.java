package section4_3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) {
		String str  = "";
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		while(true) {
			System.out.print("プログラムを実行し続けますか? ");
			try {
				str = reader.readLine();
                switch(str) {
                case "yes": 
                	continue;
                case "y": 
                	continue;
                case "no": 
                	break;
                case "n": 
                    break;
                default:
                	break;
                }
                break;
			} catch(IOException e) {
				System.out.println("Error");
				break;
			}
		}
	}
	
}
