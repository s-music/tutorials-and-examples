package section5_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	
	public static final double pai = 3.14;
	
	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("面積を求めたい図形を選択してください。(長方形: 0、三角形: 1、円: 2)");
			String figure = reader.readLine();
			switch (Integer.parseInt(figure)) {
			case 0:
				System.out.print("横の長さ: ");
				String x = reader.readLine();
				System.out.print("縦の長さ: ");
				String y = reader.readLine();
				System.out.println("長方形の面積: " + rectangleMeasure(Integer.parseInt(x), Integer.parseInt(y)));
				break;
			case 1: 
				System.out.print("底辺の長さ: ");
				String bottom = reader.readLine();
				System.out.print("高さ: ");
				String height = reader.readLine();
				System.out.println("三角形の面積: " + tryangleMeasure(Integer.parseInt(bottom), Integer.parseInt(height)));
				break;
			case 2:
				System.out.println("半径: ");
				String r = reader.readLine();
				System.out.println("円の面積: " + circleMeasure(Integer.parseInt(r)));
				break;
			default:
				System.out.println("入力値が不正です。");
				break;
			}
			
		} catch (IOException e) {
			System.out.println(e);
		} catch (NumberFormatException e) {
			System.out.println("入力値が不正です。");
		}
	}
	
	/**
	 * 長方形の面積を計算するメソッド
	 * @param x 横の長さ
	 * @param y 縦の長さ
	 * @return
	 */
	public static int rectangleMeasure(int x, int y) {
		int result = x * y;
		return result;
	}
	
	/**
	 * 三角形の面積を計算するメソッド
	 * @param bottom 底辺の長さ
	 * @param height 高さ
	 * @return
	 */
	public static double tryangleMeasure(int bottom, int height) {
		double result = bottom * height / 2.0;
		return result;
	}
	
	/**
	 * 円の面積を計算するメソッド
	 * @param r 半径
	 * @return
	 */
	public static double circleMeasure(int r) {
		double result = r * r * pai; 
		return result;
	}
	

}
