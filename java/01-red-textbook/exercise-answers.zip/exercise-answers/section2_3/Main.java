package section2_3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("名前:");
			String name = reader.readLine();
			System.out.print("年齢:");
			String age = reader.readLine();
			System.out.print("好きな食べ物:");
			String favoriteFood = reader.readLine();
			System.out.println(name + "さん。" + age + "歳。好きな食べ物は" + favoriteFood + "。");
		} catch (IOException e) {
			System.out.println("Error");
		}
	}

	
}
