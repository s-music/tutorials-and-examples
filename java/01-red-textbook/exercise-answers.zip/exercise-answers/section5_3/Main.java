package section5_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	
	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("値を入力してください: ");
			String str = reader.readLine();
			int num = Integer.parseInt(str);
			if(num < 1) {
				System.out.println("入力値が不正です。");
			} else {
			    System.out.println(num + "の階乗: " + factorial(num));
			}
		} catch (IOException e) {
			System.out.println(e);
		} catch (NumberFormatException e) {
			System.out.println("入力値が不正です。");
		}
	}
	
	/**
	 * 引数として撮ったnの階乗を求めるメソッド
	 * @param n 求める階乗
	 * @return
	 */
	public static int factorial(int n) {
        if (n == 1) {
			return n;
		} else {
			return n * factorial(n - 1);
		}
	}

}
