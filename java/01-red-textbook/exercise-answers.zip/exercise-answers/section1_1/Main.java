package section1_1;

public class Main {
	
	public static void main (String[] args) {
		System.out.println("10 × 1 = " + (10 * 1));
		System.out.println("10 × 2 = " + (10 * 2));
		System.out.println("10 × 3 = " + (10 * 3));
		System.out.println("10 × 4 = " + (10 * 4));
		System.out.println("10 × 5 = " + (10 * 5));
		System.out.println("10 × 6 = " + (10 * 6));
		System.out.println("10 × 7 = " + (10 * 7));
		System.out.println("10 × 8 = " + (10 * 8));
		System.out.println("10 × 9 = " + (10 * 9));
		System.out.println("10 × 10 = " + (10 * 10));
	}
	
}
