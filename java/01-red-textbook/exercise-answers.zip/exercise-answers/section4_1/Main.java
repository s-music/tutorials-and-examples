package section4_1;

public class Main {
	
	private static final String star = "*";
	
	public static void main(String[] args) {
		for(int i = 1; i < 16; i++) {
			String str = "";
			if(i < 8) {
			    for(int j = 0; j < i; j++) {
				    str += star;
			    }
			} else {
				for(int j = 0; j < 16 - i; j++) {
					str += star;
				}
			}
			System.out.println(str);
		}
	}
	
}
