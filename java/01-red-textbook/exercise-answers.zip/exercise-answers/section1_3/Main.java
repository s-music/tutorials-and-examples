package section1_3;

public class Main {

	public static void main(String[] args) {
		System.out.println("(2 + 3)^2 × 4 - 6 = " + ((2 + 3) * (2 + 3) * 4 - 6));
	}
	
}
