package section2_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("値を入力してください。:");
			String str = reader.readLine();
			int num = Integer.parseInt(str);
			System.out.println("絶対値: " + Math.abs(num));
		} catch (IOException e) {
			System.out.println("Error");
		}
	}
	
}
