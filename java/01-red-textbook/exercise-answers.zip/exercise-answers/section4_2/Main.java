package section4_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	
	public static void main(String[] args) {
		String str = "";
		int num = 0;
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("値を入力してください。:");
			str = reader.readLine();
			num = Integer.parseInt(str);
			for(int i = 0; i < num; i++) {
				// 2より小さい値の場合かつ2より大きい偶数の場合ループを抜ける
				if(i < 2 || ((i > 2) && (i % 2 == 0))) {
					continue;
				}
				for (int j = 2; j < i; j++) {
					if(i % j == 0) {
						break;
					} else if(i == j + 1) {
						System.out.println(i);
					}
				}
			}
		} catch (IOException e) {
			System.out.println("Error");
		} catch (NumberFormatException e) {
			System.out.println("入力値が不正です。");
		}
	}

}
