package section3_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main (String[] args) {
		int result = 0; //　結果
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("値を入力してください。");
			System.out.print("演算子の左辺:");
			String leftNumStr = reader.readLine();
			System.out.print("演算子(+, -, *, /):");
			String operator = reader.readLine();
			System.out.print("演算子の右辺:");
			String rightNumStr = reader.readLine();
			int leftNum = Integer.parseInt(leftNumStr);
			int rightNum = Integer.parseInt(rightNumStr);
			switch(operator) {
			case "+":
				result = leftNum + rightNum;
				break;
			case "-":
				result = leftNum - rightNum;
				break;
			case "*":
				result = leftNum * rightNum;
				break;
			case "/":
				result = leftNum / rightNum;
				break;
			default:
				System.out.println("演算子が不正です。");
				return;
			}
			System.out.println("結果: " + result);
		} catch (IOException e) {
			System.out.println("Error");
		} catch (NumberFormatException e) {
			System.out.println("値が不正です。");
		}
	}
	
}
