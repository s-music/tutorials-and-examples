package section5_3;

public class Main {

	private static final int max = 20;
	
	public static void main(String[] args) {
		for(int i = 0; i < max; i++) {
		    System.out.print(fibonacci(i) + ", ");
		}
		System.out.println(fibonacci(max));
	}
	
	public static int fibonacci(int n) {
		switch(n) {
		case 0: 
			return 0;
		case 1:
			return 1;
		default:
			return fibonacci(n - 1) + fibonacci(n - 2);
		}
	}
	
}
