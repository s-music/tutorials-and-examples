package section1_2;

public class Main {

	public static void main(String[] args) {
		System.out.println("球の面積: " + (4 * 3.14  * 20 * 20));
	}
	
}
