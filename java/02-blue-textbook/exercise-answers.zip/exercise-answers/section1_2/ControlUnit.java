package section1_2;

public class ControlUnit {
	
	// コンストラクタ
	public ControlUnit() {}

}
