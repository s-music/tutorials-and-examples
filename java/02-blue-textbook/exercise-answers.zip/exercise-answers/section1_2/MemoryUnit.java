package section1_2;

public class MemoryUnit {

	// コンストラクタ
	public MemoryUnit() {}
	
}
