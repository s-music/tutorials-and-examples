package section1_2;

public class ArithmeticLogicUnit {

	// コンストラクタ
	public ArithmeticLogicUnit() {}
	
}
