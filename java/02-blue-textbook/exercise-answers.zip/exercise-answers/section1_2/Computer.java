package section1_2;

public class Computer {

	// フィールド
	private InputUnit inputUnit = new InputUnit(); 
	private MemoryUnit memoryUnit = new MemoryUnit(); 
	private ControlUnit controlUnit = new ControlUnit(); 
	private ArithmeticLogicUnit arithmeticLogicUnit = new ArithmeticLogicUnit(); 
	private OutputUnit outputUnit = new OutputUnit();

	// コンストラクタ
	public Computer() {}
	
}
