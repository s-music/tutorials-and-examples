package section1_2;

public class OutputUnit {

	// コンストラクタ
	public OutputUnit() {}
	
}
