package section1_2;

public class InputUnit {

	// コンストラクタ
	public InputUnit() {}
	
}
