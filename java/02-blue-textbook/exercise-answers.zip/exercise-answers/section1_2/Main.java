package section1_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	// フィールド
	private static int total;
 	
	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		while(true) {
		   try {
			   System.out.print("台数を入力または実行の終了(exit or e)を行ってください:");
			   String str = reader.readLine();
			   if (str.matches("exit") || str.matches("e")) {
				   return;
			   }
			   int num = Integer.parseInt(str);
			   for (int i = 0; i < num; i++) {
				   Computer computer = new Computer();
			   }
			   total += num;
			   System.out.println("生産した台数は" + num + "台、総生産数は" + total + "台です。");
		   } catch(IOException e) {
			   System.out.println(e);
		   } catch(NumberFormatException e) {
			   System.out.println("入力値が不正です。");
		   }
		}
	}
	
}
