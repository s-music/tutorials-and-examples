package section2_3;

public abstract class Stew {
	
	protected abstract void cutVegetables(); // 野菜を切る
	protected abstract void stirFryVegetables(); // 野菜を炒める
	protected abstract void simmerVegetables(); // 野菜を煮込む
	protected abstract void putLou(); // ルーを入れる
	protected abstract void simmer(); // 煮込む
    public final void cook() {
        cutVegetables();
        stirFryVegetables();
        simmerVegetables();
        putLou();
        simmer();
    }
    
}
