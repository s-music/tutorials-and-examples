package section2_3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		while (true) {
			try {
				System.out.print("作りたい料理を選択してください(1: カレー, 2: クリームシチュー): ");
				String str = reader.readLine();
				int num = Integer.parseInt(str);
				switch(num) {
				case 1:
					new Curry().cook();
					break;
				case 2:
					new CreamStew().cook();
					break;
				default:
					System.out.println("入力値が不正です。");
					return;
				}
			} catch (IOException e) {
				System.out.println("Error");
			} catch (NumberFormatException e) {
				System.out.println("入力値が不正です。");
			}
		}
	}

}
