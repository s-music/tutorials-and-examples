package section2_3;

public class Curry extends Stew {

	// コンストラクタ
	public Curry () {}

	// クラスメソッド
	@Override protected void cutVegetables() { // 野菜を切る
		System.out.println("じゃがいも、ニンジン、玉ねぎを切ります。");
	};
	
	@Override protected void stirFryVegetables() { // 野菜を炒める
		System.out.println("野菜炒めます。");
	};
	
	@Override protected void simmerVegetables() { // 野菜を煮込む
		System.out.println("野菜を煮込みます。");
	};
	
	@Override protected void putLou() { // ルーを入れる
		System.out.println("カレーのルウを入れます。");
	};
	
	@Override protected  void simmer() { // 煮込む
		System.out.println("弱火で煮込みます。");
	};
	
}
