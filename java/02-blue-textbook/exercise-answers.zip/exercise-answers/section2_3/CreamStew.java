package section2_3;

public class CreamStew extends Stew {

	// コンストラクタ
	public CreamStew () {}

	// クラスメソッド
	@Override protected void cutVegetables() { // 野菜を切る
		System.out.println("じゃがいも、ニンジン、玉ねぎ、きのこを切ります。");
	};

	@Override protected void stirFryVegetables() { // 野菜を炒める
		System.out.println("野菜炒めます。");
	};

	@Override protected void simmerVegetables() { // 野菜を煮込む
		System.out.println("野菜を煮込みます。");
	};

	@Override protected void putLou() { // ルーを入れる
		System.out.println("クリームシチューのルウと少量の牛乳を入れます。");
	};
	
	@Override protected  void simmer() { // 煮込む
		System.out.println("弱火で煮込みます。");
	};

}
