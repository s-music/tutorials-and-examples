package section1_1;

public class Animal {
	
	public void bark() {}

}
