package section1_1;

public class Dog extends Animal {

	// コンストラクタ
	public Dog() {}
	
	// インスタンスメソッド
	@Override public void bark() {
		System.out.println("woof");
	}
 	
}
