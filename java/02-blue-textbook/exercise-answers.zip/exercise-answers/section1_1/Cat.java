package section1_1;

public class Cat extends Animal {

	// コンストラクタ
	public Cat() {}
	
	// インスタンスメソッド
	@Override public void bark() {
		System.out.println("meow");
	}
	
}
