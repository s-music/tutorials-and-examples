package section5_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public abstract class FactoryProcess implements Runnable {

	protected abstract int getNum(); // 台数を取得する関数
	protected abstract int getType(); // 生産するコンピュータのタイプを取得する関数
	protected abstract void mainProcess(int num, int type); // 実際にコンピュータを作成する工程
	// Factory Process
	public void run() {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in)) ;
		while(true) {
		   int num = getNum();
		   int type =  getType();
		   mainProcess(num, type);
		   System.out.print("作業を続けますか?(y/n): ");
		   try {
			   String str = reader.readLine();
			   if(str.matches("y")) {
			  	 continue;
			   } else if (str.matches("n")){
			  	 break;
			   } else {
			  	 System.out.println("入力値が不正です。");
			  	 break;
			   }
		   } catch(IOException e) {
		  	 System.out.println(e);
		   }
		}
	}
	
	
}
