package section5_1;

public class ControlUnit {
	
	// フィールド
	public String type;
	
	// コンストラクタ
	private ControlUnit(String type) {
		this.type = type;
	}
	
	// クラスメソッド
	public static ControlUnit getControlUnitTypeA () {
		return new ControlUnit("Aタイプ");
	}
	
	public static ControlUnit getControlUnitTypeB () {
		return new ControlUnit("Bタイプ");
	}
	
	// インスタンスメソッド
	@Override public String toString() {
		return "C: " + type;
	}
}
