package section5_1;

public class Computer {

	// フィールド
	private InputUnit inputUnit;
	private MemoryUnit memoryUnit;
	private ControlUnit controlUnit;
	private ArithmeticLogicUnit arithmeticLogicUnit;
	private OutputUnit outputUnit;

	// コンストラクタ
	private Computer( // privateで隠蔽する
	    InputUnit inputUnit, MemoryUnit memoryUnit, ControlUnit controlUnit, ArithmeticLogicUnit arithmeticLogicUnit,
	    OutputUnit outputUnit) {
		this.inputUnit = inputUnit;
		this.memoryUnit = memoryUnit;
		this.controlUnit = controlUnit;
		this.arithmeticLogicUnit = arithmeticLogicUnit;
		this.outputUnit = outputUnit;
	}

	// クラスメソッド
	public static Computer createTypeA() {
		return new Computer(InputUnit.getInputUnitTypeA(), MemoryUnit.getMemoryUnitTypeA(), ControlUnit.getControlUnitTypeA(),
		    ArithmeticLogicUnit.getArithmeticLogicUnitTypeA(), OutputUnit.getOutputUnitTypeA());
	}

	public static Computer createTypeB() {
		return new Computer(InputUnit.getInputUnitTypeB(), MemoryUnit.getMemoryUnitTypeB(), ControlUnit.getControlUnitTypeB(),
		    ArithmeticLogicUnit.getArithmeticLogicUnitTypeB(), OutputUnit.getOutputUnitTypeB());
	}
	
}
