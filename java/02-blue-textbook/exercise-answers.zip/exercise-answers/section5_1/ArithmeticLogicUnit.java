package section5_1;

public class ArithmeticLogicUnit {

	// フィールド
	public String type;
	
	// コンストラクタ
	private ArithmeticLogicUnit(String type) {
		this.type = type;
	}
	
	// クラスメソッド
	public static ArithmeticLogicUnit getArithmeticLogicUnitTypeA () {
		return new ArithmeticLogicUnit("Aタイプ");
	}
		
	public static ArithmeticLogicUnit getArithmeticLogicUnitTypeB () {
		return new ArithmeticLogicUnit("Bタイプ");
	}
		
	// インスタンスメソッド
	@Override public String toString() {
		return "A/L: " + type;
	}
	
}
