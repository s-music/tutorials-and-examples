package section5_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ComputerFactory extends FactoryProcess {

	private BufferedReader reader;
	private List<Computer> typeAStock = new ArrayList<Computer>();
	private List<Computer> typeBStock = new ArrayList<Computer>();

	// コンストラクタ
	public ComputerFactory() {
		this.reader = new BufferedReader(new InputStreamReader(System.in));
	}

	// クラスメソッド
	@Override
	protected int getNum() {
		while (true) {
			try {
				System.out.print("台数を入力してください: ");
				String str = reader.readLine();
				int num = Integer.parseInt(str);
				if (num > 0) {
					return num;
				} else {
					System.out.println("入力値が不正です。");
					continue;
				}
			} catch (IOException e) {
				System.out.println(e);
			} catch (NumberFormatException e) {
				System.out.println("入力値が不正です。");
			}
		}
	}

	@Override
	protected int getType() {
		while (true) {
			try {
				System.out.print("生産するコンピュータのタイプを指定してください(A: 0, B: 1): ");
				String str = reader.readLine();
				int type = Integer.parseInt(str);
				switch (type) {
				case 0:
					return type;
				case 1:
					return type;
				default:
					System.out.println("入力値が不正です。");
					continue;
				}
			} catch (IOException e) {
				System.out.println(e);
			} catch (NumberFormatException e) {
				System.out.println("入力値が不正です。");
			}
		}
	}

	@Override
	protected void mainProcess(int num, int type) {
		switch (type) {
		case 0:
			for (int i = 0; i < num; i++) {
				typeAStock.add(Computer.createTypeA());
			}
			break;
		case 1:
			for (int i = 0; i < num; i++) {
				typeBStock.add(Computer.createTypeB());
			}
			break;
		default:
			break;
		}
		System.out.println("現在の在庫数 A: " +  typeAStock.size() + "台 B: " + typeBStock.size() + "台");
	}

}
