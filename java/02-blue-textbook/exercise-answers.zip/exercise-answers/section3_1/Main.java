package section3_1;

import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main (String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("出力先のファイルを指定してください:");
			String fileName = reader.readLine();
			System.out.print("出力したい文字列を入力してください:");
			String str = reader.readLine(); 
			FileWriter fileWriter = new FileWriter(fileName);
			fileWriter.write(str);
			fileWriter.close();
			System.out.println("ファイルに文字列を出力しました。");
		} catch (IOException e) {
			System.out.println("Error");
		}
	}
	
}
