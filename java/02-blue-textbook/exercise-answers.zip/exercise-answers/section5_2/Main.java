package section5_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

public class Main {

	private static final HashMap<Integer, String> week = new HashMap<Integer, String>();
	static {
		week.put(0, "日");
		week.put(1, "月");
		week.put(2, "火");
		week.put(3, "水");
		week.put(4, "木");
		week.put(5, "金");
		week.put(6, "土");
	}

	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		while (true) {
			try {
				System.out.print("曜日番号を入力してください(0: 日,1: 月, 2: 火, 3: 水, 4: 木, 5: 金, 6: 土): ");
				String str = reader.readLine();
				int num = Integer.parseInt(str);
				if (0 < num && num < 6) {
					System.out.println(week.get(num));
				} else {
					System.out.println("入力値が不正です。");
					return;
				}
			} catch (IOException e) {
				System.out.println(e);
			} catch (NumberFormatException e) {
				System.out.println("入力値が不正です。");
				return;
			}
		}
	}

}
