package section2_2;

public class Main {
	
	public static void main(String[] args) {
		Dog dog = new Dog();
		Cat cat = new Cat();
		DogRobot dogRobot = new DogRobot();
		CatRobot catRobot = new CatRobot();
		dog.bark();
		cat.bark();
		dogRobot.bark();
		catRobot.bark();
	}

}
