package section2_2;

public interface AnimalTrait {
	
	public abstract void bark();

}
