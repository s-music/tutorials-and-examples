package section2_2;

public class Robot {

}
