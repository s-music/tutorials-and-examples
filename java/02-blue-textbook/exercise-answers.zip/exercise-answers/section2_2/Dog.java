package section2_2;

public class Dog extends Animal implements AnimalTrait {

	// コンストラクタ
	public Dog() {}
	
	// インスタンスメソッド
	@Override public void bark() {
		System.out.println("woof");
	}
 	
}
