package section2_2;

public class CatRobot extends Robot implements AnimalTrait {
	
	// コンストラクタ
	public CatRobot() {}
		
	// インスタンスメソッド
	@Override public void bark() {
		System.out.println("meow");
	}

}
