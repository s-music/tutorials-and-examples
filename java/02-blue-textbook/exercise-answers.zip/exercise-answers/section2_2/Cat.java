package section2_2;

public class Cat extends Animal implements AnimalTrait {

	// コンストラクタ
	public Cat() {}
	
	// インスタンスメソッド
	@Override public void bark() {
		System.out.println("meow");
	}
	
}
