package section2_2;

public class DogRobot extends Robot implements AnimalTrait {
 
	// コンストラクタ
	public DogRobot() {}
	
	// インスタンスメソッド
	@Override public void bark() {
		System.out.println("woof");
	}
 	
}
