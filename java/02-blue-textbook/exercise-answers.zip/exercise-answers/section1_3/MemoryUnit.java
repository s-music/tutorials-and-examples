package section1_3;

public class MemoryUnit {

	// フィールド
	public String type;
	
	// コンストラクタ
	private  MemoryUnit(String type) {
		this.type = type;
	}
	
	// クラスメソッド
	public static MemoryUnit getMemoryUnitTypeA () {
		return new MemoryUnit("8G");
	}
	
	public static MemoryUnit getMemoryUnitTypeB () {
		return new MemoryUnit("4G");
	}
	
	// インスタンスメソッド
	@Override public String toString() {
		return "M: " + type;
	}
	
}
