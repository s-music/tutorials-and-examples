package section1_3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	// フィールド
	private static int total;
 	
	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		while(true) {
		   try {
			   System.out.print("台数を入力または実行の終了(exit or e)を行ってください:");
			   String str = reader.readLine();
			   if (str.matches("exit") || str.matches("e")) {
				   return;
			   }
			   int num = Integer.parseInt(str);
			   System.out.println("生産するコンピュータのタイプを指定してください(A or B)");
			   str = reader.readLine();
			   switch(str) {
			   case "A":
				   for(int i = 0; i < num; i++) {
					   Computer.createTypeA();
				   }
				   break;
			   case "B":
				   for(int i = 0; i < num; i++) {
				       Computer.createTypeB();
				   }
				   break;
			   default:
				   System.out.println("入力値が不正です。");
				   return;
			   }
			   total += num;
			   System.out.println("生産した台数は" + num + "台、総生産数は" + total + "台です。");
		   } catch(IOException e) {
			   System.out.println(e);
		   } catch(NumberFormatException e) {
			   System.out.println("入力値が不正です。");
		   }
		}
	}
	
}
