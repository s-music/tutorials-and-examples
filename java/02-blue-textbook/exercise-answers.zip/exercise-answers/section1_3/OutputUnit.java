package section1_3;

public class OutputUnit {

	// フィールド
	public String structure;
	
	// コンストラクタ
	public OutputUnit(String structure) {
		this.structure = structure;
	}

	// クラスメソッド
	public static OutputUnit getOutputUnitTypeA() {
		return new OutputUnit("ディスプレイ");
	}

	public static OutputUnit getOutputUnitTypeB() {
		return new OutputUnit("ディスプレイ、スピーカー");
	}

	// インスタンスメソッド
	@Override
	public String toString() {
		return "O: " + structure;
	}

}
