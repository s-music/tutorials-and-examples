package section1_3;

public class InputUnit {
	
	// フィールド
	public String structure;
	
	// コンストラクタ
	private InputUnit(String structure) {
		this.structure = structure;
	}
	
	// クラスメソッド
	public static InputUnit getInputUnitTypeA () {
		return new InputUnit("キーボード");
	}
	
	public static InputUnit getInputUnitTypeB () {
		return new InputUnit("キーボード、マウス");
	}
	
	// インスタンスメソッド
	@Override public String toString() {
        return "I: " + structure;		
	}
	
}
