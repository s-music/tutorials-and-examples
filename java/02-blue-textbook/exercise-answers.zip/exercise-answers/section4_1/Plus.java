package section4_1;

public class Plus implements Runnable {

	// フィールド
	private static final int delayTime = 3000;
	
	// コンストラクタ
	public Plus () {}
	
	// インスンタンスメソッド
	@Override public void run() {
		while(true) {
			try {
				Thread.sleep(delayTime);
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
		    System.out.println("+++");
		}
	}
	
}
