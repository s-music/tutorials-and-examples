package section4_1;

public class Main {
	
	public static void main(String[] args) {
        Thread thread1 = new Thread(new Plus());
        Thread thread2 = new Thread(new Minus());
        thread1.start();
        thread2.start();
	}

}
