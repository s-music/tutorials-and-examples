package section4_1;

public class Minus implements Runnable {

	// フィールド
	private static final int delayTime = 4000;
	
	// コンストラクタ
    public Minus () {}

    // インスンタンスメソッド
	@Override public void run() {
		while(true) {
			try {
				Thread.sleep(delayTime);
			} catch (InterruptedException e) {
				e.printStackTrace();
				return;
			}
		    System.out.println("---");
		}
	}

}
