package func7_2;

import static func7_2.TailCalls.done;
import static func7_2.TailCalls.call;

public class Fibonacci {

	// コンストラクタ
	public Fibonacci() {}

	// インスタンスメソッド
	/**
	 * フィボナッチ数取得メソッド
	 * @param n
	 * @return
	 */
	public long calc(final int n) {
		return process(0, 1, n).invoke();
	}
	
	/**
	 * フィボナッチ数を計算するメソッド
	 * @param n
	 * @return
	 */
	private TailCall<Long> process(long n1, long n2, long n) {
		if (n == 0) {
			return done(Integer.toUnsignedLong(0));
		} else if(n == 1) {
			return done(n2);
		} else {
			return call(() -> process(n2, n1 + n2, n - 1));
		}
	}
	
}
