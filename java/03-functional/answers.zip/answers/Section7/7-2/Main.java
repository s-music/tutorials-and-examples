package func7_2;

public class Main {
	
	private static final int N = 50;

	public static void main (String[] args) {
		Fibonacci fibonacci = new Fibonacci();
		for (int i = 0; i < N; i++) {
			if(i < N - 1) {
			  System.out.print(fibonacci.calc(i) + ", ");
			} else {
				System.out.print(fibonacci.calc(i));
			}
		}
	}
	
}
