package func7_2;

import java.util.stream.Stream;

@FunctionalInterface
public interface TailCall<T> {
	
	public abstract TailCall<T> apply();
	
	// デフォルトメソッド
	/**
	 * 終了判定メソッド
	 * @return
	 */
	default public boolean isComplete() {
		return false;
	}
	
	/**
	 * 結果を返すメソッド
	 * @return
	 */
	default public T result () {
		throw new Error("not implemented");
	}
	
	/**
	 * メインロジック
	 * @return
	 */
	default public T invoke() {
		return Stream.iterate(this, TailCall::apply) // 最初の呼び出しで生成されたTailCallを元にストリームを生成
				         .filter(TailCall::isComplete) // 最後の処理(isCompleteがtrueを返す処理)をフィルタリング
				         .findFirst()
				         .get()
				         .result(); // trueになった時点の結果を返す。
	}
	
}
