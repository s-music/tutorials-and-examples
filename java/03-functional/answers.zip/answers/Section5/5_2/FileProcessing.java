package func5_2;

@FunctionalInterface
public interface FileProcessing<T, E extends Throwable> {
	
	public abstract void accept(T instance) throws E;

}
