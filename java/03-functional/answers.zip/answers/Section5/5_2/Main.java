package func5_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main (String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("出力先のファイルを指定してください:");
			String fileName = reader.readLine();
			System.out.print("出力したい文字列を入力してください:");
			String str = reader.readLine(); 
			FileManager.use(fileName, fileManager -> fileManager.writeToFile(str));
		} catch (IOException e) {
			System.out.println("Error");
		}
	}
	
}
