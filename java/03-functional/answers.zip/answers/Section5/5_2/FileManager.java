package func5_2;

import java.io.FileWriter;
import java.io.IOException;

public class FileManager {
	
	/** フィールド　**/
	private static FileWriter fileWriter;
	
  /**
   * コンストラクタ
   * @param path
   */
	private FileManager(String path) throws IOException {
		System.out.println("ファイルをオープンします。");
	  fileWriter = new FileWriter(path);
	}
	
	/** クラスメソッド **/

	/**
	 * FileManagerを利用するためのエンドポイント	
	 * @param fileName
	 * @param process
	 * @throws IOException
	 */
	public static void use(String fileName, final FileProcessing<FileManager, IOException> process) throws IOException {
		FileManager fileManager = new FileManager(fileName);
		try {
			process.accept(fileManager);
		} finally {
			fileManager.close();
		}
	}
	
	/** インスタンスメソッド **/
	
	/**
	 *  ファイルクローズ
	 */
	private void close() throws IOException {
		System.out.println("ファイルをクローズします。");
		fileWriter.close();
	}
	
	/**
	 *  ファイルへの書き込みメソッド
	 * 　@param str
	 */
	public void writeToFile(String str) throws IOException {
		System.out.println("ファイルに書き込みをおこないます。");
		fileWriter.write(str);
	}
	

	
}
