package func6_2;

import func6_2.Product.ProductType;

public class ProductMachine {
	
	public static String name = "";
	public static String code = "";
	public static ProductType type = ProductType.Undefined;
	public static int price = 0;
	
	// コンストラクタ
	public ProductMachine() {}
	
	// インスタンスメソッド
	public Product createProduct() {
		return new Product(name, code, type, price);
	}
 	
}
