package func6_2;

import java.util.function.Supplier;

import func6_2.Product.ProductType;

public class ProductFactory implements Runnable {
	
	private static ProductFactory factory = new ProductFactory();
	private static Supplier<ProductMachine> machine =  () -> new ProductMachine();
	public static String thread1Name = "Thread1";
	public static String thread2Name = "Thread2";
	private static int thread1Num = 0;
	private static int thread2Num = 0;

	// コンストラクタ
	private ProductFactory() {}
	
	// クラスメソッド
	/**
	 * ProductFactoryのインスタンスの取得
	 * @return ProductFactoryのインスタンス
	 */
	public static ProductFactory getInstance() {
	  return factory;
	}
	
	/**
	 * 
	 * メインの処理
	 * 1度目の呼び出しでmachineにインスタンスを格納し、2度目の呼び出し以降はそのインスタンスを使い回すように実装
	 * @param currentThread
	 */
  private static void runFactory(String currentThread) {
  	class MachineSupplier implements Supplier<ProductMachine> {
  		// フィールド
  		private final ProductMachine machine = new ProductMachine();
  		
  		// コンストラクタ
  		public MachineSupplier() {}

  		// インスタンスメソッド
  		@Override public ProductMachine get() {
  			return machine;
  		}
  		
  	}
  	if(!MachineSupplier.class.isInstance(machine)) {
  		machine = new MachineSupplier();
  	}
  	System.out.println(currentThread + ":" + machine.get().createProduct());
	}
	
	// インスタンスメソッド
  /**
   * ProductFactoryのセットアップ
   * @param num1 
   * @param num2 
   */
  public void factorySetup(int num1, int num2) {
  	thread1Num = num1;
  	thread2Num = num2;
  }
  
  /**
   * ProductMachineのセットアップ
   * @param name 
   * @param code 
   * @param type
   * @param value
   */
  public void machineSetup(String name, String code, ProductType type, int price) {
  	ProductMachine.name = name;
  	ProductMachine.code = code;
  	ProductMachine.type = type;
  	ProductMachine.price = price;
  }
  
	@Override public void run() {
		int num; 
		String currentThread = Thread.currentThread().toString();
		if (thread1Name.matches(currentThread)) {
			num = thread1Num;
		} else {
			num = thread2Num;
		}
		for(int i = 0; i < num; i++) {
		  runFactory(currentThread);
		}
	}
	
}
