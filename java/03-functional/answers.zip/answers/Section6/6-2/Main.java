package func6_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import func6_2.Product.ProductType;

public class Main {

	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		try {
			while (true) {
				// パラメータの取得
				System.out.print("商品名を入力してください: ");
				String name = reader.readLine();
				System.out.print("商品コードを入力してください: ");
				String code = reader.readLine();
				System.out.print("種別を入力してください(0: A, 1: B, 2: C, 3: D): ");
				String str = reader.readLine();
				int typeNum = Integer.parseInt(str);
				ProductType type = ProductType.checkType(typeNum);
				if (type == ProductType.Undefined) {
					System.out.println("入力値が不正です。");
					return;
				}
				System.out.print("価格を入力してください: ");
				str = reader.readLine();
				int price = Integer.parseInt(str);
				System.out.print("thread1に生産させる個数を入力してください: ");
				str = reader.readLine();
				int num1 = Integer.parseInt(str);
				System.out.print("thread2に生産させる個数を入力してください: ");
				str = reader.readLine();
				int num2 = Integer.parseInt(str);
				ProductFactory factory = ProductFactory.getInstance();
				factory.factorySetup(num1, num2);
				factory.machineSetup(name, code, type, price); // ProductMachineのセットアップ
				Thread thread1 = new Thread(factory, ProductFactory.thread1Name);
				Thread thread2 = new Thread(factory, ProductFactory.thread2Name);
				thread1.start();
				thread2.start();
				try {
					thread1.join();
					thread2.join();
				} catch (InterruptedException e) {
					System.out.println(e);
				}
			}
		} catch (IOException e) {
			System.out.println(e);
		} catch (NumberFormatException e) {
			System.out.println("入力値が不正です。");
		}
	}

}
