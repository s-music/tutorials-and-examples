package func3_2;

public class Product {

	  /** フィールド **/
	  private String name = ""; // 商品名
	  private String code = ""; // 商品コード
	  private ProductType type = ProductType.TypeA; // 商品種別
	  private int value = 0; // 値段(円)

	  public static enum ProductType {
	    TypeA,
	    TypeB,
	    TypeC,
	    TypeD
	  };

	  /** コンストラクタ **/
	  public Product(String name, String code, ProductType type, int value) {
	    this.name = name;
	    this.code = code;
	    this.type = type;
	    this.value = value;
	  }

	  /** インスタンスメソッド **/
	  public String getName() {
	      return this.name;
	  }

	  public String getCode() {
	      return this.code;
	  }

	  public ProductType getType() {
	      return this.type;
	  }

	  public int getValue() {
	      return this.value;
	  }

	  @Override public String toString() {
	      return String.format("商品名: %s, 商品コード: %s, 種別: %s,  価格: %d", this.name, this.code, this.type , this.value);
	  }

	}
