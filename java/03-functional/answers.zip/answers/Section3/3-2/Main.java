package func3_2;

import java.util.*;
import java.util.stream.Collectors;

import func3_2.Product.ProductType;

public class Main {
  
  private static List<Product> products = Arrays.asList(
      new Product("商品A", "0001", ProductType.TypeA, 100),
      new Product("商品B", "0002", ProductType.TypeA, 500),
      new Product("商品C", "0003", ProductType.TypeB, 5000),
      new Product("商品D", "0004", ProductType.TypeC, 300),
      new Product("商品E", "0005", ProductType.TypeB, 400),
      new Product("商品F", "0006", ProductType.TypeD, 200),
      new Product("商品G", "0007", ProductType.TypeA, 10),
      new Product("商品H", "0008", ProductType.TypeD, 3000),
      new Product("商品I", "0009", ProductType.TypeB, 1500),
      new Product("商品J", "0010", ProductType.TypeC, 450)
  );

  public static void main(String[] args) {
    System.out.println("商品A: ");
    products.stream()
        .filter(p -> p.getType() == ProductType.TypeA && p.getValue() < 1000)
        .sorted((p1, p2) -> p2.getValue() - p1.getValue())
        .collect(Collectors.toList())
        .forEach(System.out::println);
    System.out.println("");
    System.out.println("商品C: ");
    products.stream()
        .filter(p -> p.getType() == ProductType.TypeC && p.getValue() < 1000)
        .sorted((p1, p2) -> p2.getValue() - p1.getValue())
        .collect(Collectors.toList())
        .forEach(System.out::println);
  }
  
}
