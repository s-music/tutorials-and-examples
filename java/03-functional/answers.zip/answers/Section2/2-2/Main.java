import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Main {
  
  /** fields **/
  private static final List<String> friends = Arrays.asList("Tom", "Alice", "Bob", "Clis", "Jacob");
  
  /**
   * 引数で渡されたletterを含んでいるかどうかを判定するメソッド
   * @param letter
   */
  private static Function<String, Predicate<String>> checkIfContainsLetter = 
      letter -> name -> name.contains(letter.toLowerCase()) || name.contains(letter.toUpperCase());
    
  /**
   * 引数で渡されたリストの中から、letterを含むものを表示する。
   * @param list: List<String> 対象のリスト
   * @param letter: String  判定したい文字列
   * @result result: String 結果の文字列
   */
  private static String getContainsLetter(List<String> list, String letter) {
    String result = list.stream()
        .filter(checkIfContainsLetter.apply(letter))
        .map(String::toUpperCase)
        .collect(Collectors.joining(", "));
    return result;
  }

  public static void main(String[] args) {
    System.out.println(getContainsLetter(friends, "a"));
    System.out.println(getContainsLetter(friends, "b"));
    System.out.println(getContainsLetter(friends, "c"));
  }
  
}
